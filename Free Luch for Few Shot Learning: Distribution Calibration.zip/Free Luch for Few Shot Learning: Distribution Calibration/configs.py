save_dir                    = '.'
data_dir = {}
data_dir['cifar']             = './filelists/cifar/' 
data_dir['CUB']             = './filelists/CUB/' 
data_dir['miniImagenet']    = './filelists/miniImagenet/' 
